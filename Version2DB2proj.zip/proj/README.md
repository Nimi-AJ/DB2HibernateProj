# DB2HibernateProj
A springboot project based on JPA, Hibernate and IBM's DB2
