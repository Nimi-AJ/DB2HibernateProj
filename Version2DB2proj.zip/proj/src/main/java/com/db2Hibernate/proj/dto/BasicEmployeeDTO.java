package com.db2Hibernate.proj.dto;

public interface BasicEmployeeDTO {
    String getFirstName();

    String getLastName();

    String getAge();

    String getEmail();

    Integer getSalary();


    Long getId();



}
